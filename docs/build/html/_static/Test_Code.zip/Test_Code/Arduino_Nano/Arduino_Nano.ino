const int testPins[] = {
    2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,  
    19, 18, 17, 16, 15, 14, 13                                      
};

const int totalPins = sizeof(testPins) / sizeof(testPins[0]);

void setup() {
    for (int i = 0; i < totalPins; i++) {
        pinMode(testPins[i], OUTPUT);
        digitalWrite(testPins[i], LOW);
    }
}

void loop() {
    // Forward direction
    for (int i = 0; i < totalPins; i++) {
        digitalWrite(testPins[i], HIGH);
        delay(500);
        digitalWrite(testPins[i], LOW);
    }
    
    // Backward direction
    for (int i = totalPins - 1; i >= 0; i--) {
        digitalWrite(testPins[i], HIGH);
        delay(500);
        digitalWrite(testPins[i], LOW);
    }
}