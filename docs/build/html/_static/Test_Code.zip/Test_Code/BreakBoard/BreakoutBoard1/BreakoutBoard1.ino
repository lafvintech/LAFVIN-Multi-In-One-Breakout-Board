const int testPins[] = {15, 23, 4, 5, 18, 19, 21, 22, 2, 12, 13, 14, 25, 26, 27, 32, 33}; 
bool state = true;

void setup() {
  for (int i = 0; i < sizeof(testPins) / sizeof(testPins[0]); i++) {
    pinMode(testPins[i], OUTPUT);
  }
}

void loop() {
  for (int i = 0; i < sizeof(testPins) / sizeof(testPins[0]); i++) {
    digitalWrite(testPins[i], state);
  }
  state = !state;
  delay(1000);
}