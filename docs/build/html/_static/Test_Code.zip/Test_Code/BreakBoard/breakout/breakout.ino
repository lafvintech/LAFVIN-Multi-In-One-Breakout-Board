//ESP32 Flowing Light Test Program
//Suitable for LAFVIN Multi In-One Breakout Board
//Updated on：2026.06

const int testPins[] = {15, 2, 4, 5, 18, 19, 21, 22, 23, 13, 12, 14, 27, 26, 25, 33, 32, };
void setup() {
  for (int i = 0; i < sizeof(testPins) / sizeof(testPins[0]); i++) {
    pinMode(testPins[i], OUTPUT);
  }
}
void loop() {
  for (int i = 0; i < sizeof(testPins) / sizeof(testPins[0]); i++) {
    digitalWrite(testPins[i], HIGH);  
    delay(500);                        
    digitalWrite(testPins[i], LOW);   
  }
  delay(1000);
}
