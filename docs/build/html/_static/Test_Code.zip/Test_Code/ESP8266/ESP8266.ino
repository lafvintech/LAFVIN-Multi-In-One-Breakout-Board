const int testPins[] = {
    16,  // D0
    5,   // D1
    4,   // D2
    0,   // D3  
    2,   // D4
    14,  // D5
    12,  // D6
    13,  // D7
    15   // D8
};

const int totalPins = sizeof(testPins) / sizeof(testPins[0]);

void setup() {
    for (int i = 0; i < totalPins; i++) {
        pinMode(testPins[i], OUTPUT);
        digitalWrite(testPins[i], LOW);
    }
}

void loop() {
    // Forward direction
    for (int i = 0; i < totalPins; i++) {
        digitalWrite(testPins[i], HIGH);
        delay(500);
        digitalWrite(testPins[i], LOW);
    }
    
    // Backward direction
    for (int i = totalPins - 1; i >= 0; i--) {
        digitalWrite(testPins[i], HIGH);
        delay(500);
        digitalWrite(testPins[i], LOW);
    }
}