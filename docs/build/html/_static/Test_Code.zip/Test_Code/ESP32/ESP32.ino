const int testPins[] = {
    34, 35, 32, 33, 25, 26, 27, 14, 12, 13,
    23, 22, 21, 19, 18, 5, 4, 2, 15
};

const int totalPins = sizeof(testPins) / sizeof(testPins[0]);

const int scanDelay = 500;

void setup() {
    Serial.begin(115200);
    Serial.println("ESP32 Pin Scan Test Started");
    Serial.print("Total pins to test: ");
    Serial.println(totalPins);
    
    for (int i = 0; i < totalPins; i++) {
        pinMode(testPins[i], OUTPUT);
        digitalWrite(testPins[i], LOW);
        Serial.print("Pin ");
        Serial.print(testPins[i]);
        Serial.println(" initialized");
    }
    
    Serial.println("Setup complete. Starting scan loop...");
}

void loop() {

    for (int i = 0; i < totalPins; i++) {
        digitalWrite(testPins[i], HIGH);   
        delay(scanDelay);                   
        digitalWrite(testPins[i], LOW);    
    }
    
    delay(200);
    
    for (int i = totalPins - 1; i > -1; i--) {
        digitalWrite(testPins[i], HIGH);
        delay(scanDelay);
        digitalWrite(testPins[i], LOW);
    }

    delay(200);
}
