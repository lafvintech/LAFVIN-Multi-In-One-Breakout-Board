const int testPins[] = {
    4, 5, 6, 7, 15, 16, 17, 18, 8, 3, 46, 9, 10, 11, 12, 13, 14, 
    1, 2, 42, 41, 40, 39, 38, 37, 36, 35, 0, 45, 48, 47, 21, 20, 19
};

const int totalPins = sizeof(testPins) / sizeof(testPins[0]);

void setup() {
    for (int i = 0; i < totalPins; i++) {
        pinMode(testPins[i], OUTPUT);
        digitalWrite(testPins[i], LOW);
    }
}

void loop() {
    // Forward direction
    for (int i = 0; i < totalPins; i++) {
        digitalWrite(testPins[i], HIGH);
        delay(500);
        digitalWrite(testPins[i], LOW);
    }
    
    // Backward direction
    for (int i = totalPins - 1; i >= 0; i--) {
        digitalWrite(testPins[i], HIGH);
        delay(500);
        digitalWrite(testPins[i], LOW);
    }
}